<?php
session_start();

include "../internal/db_connection.php";
include "../internal/header.php";

$internal = __DIR__ . "/../internal/cerca-istruttore/";

$top = file_get_contents($internal . "top.html");
$templateResult = file_get_contents($internal . "stack.html");
$bottom = file_get_contents($internal . "bottom.html");

$nome = '';
if (isset($_GET['nome'])) {
    $nome = $_GET['nome'];
    $nome = trim($nome);
}

$top = str_replace("[Valore Ricerca]", htmlspecialchars($nome), $top);

echo renderFromHtml($top);

$query = "SELECT *
    FROM Utente
    JOIN Istruttore ON Utente.id_utente = Istruttore.id_utente
    LEFT JOIN Personal_Trainer ON Utente.id_utente = Personal_Trainer.id_istruttore
    WHERE nome LIKE ?";
$stmt = $conn->prepare($query);

$param = "%" . $nome . "%";
$stmt->bind_param("s", $param);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Nessun risultato trovato.";
}

while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
    $output = $templateResult;
    $imageFile = $row['id_utente'];
    if (!file_exists("immagini/istruttori/" . $imageFile . ".jpg")) {
        $imageFile = "default";
    }

    $isPt = $row['id_istruttore'] == null
        ? '<abbr title="no" aria-hidden="true">&cross;</abbr><span class="hidden">no</span>'
        : '<abbr title="si" aria-hidden="true">&check;</abbr><span class="hidden">si</span>';

    $output = str_replace("[Nome Istruttore]", $row['nome'] . ' ' . $row['cognome'], $output);
    $output = str_replace("[È PT]", $isPt, $output);
    $output = str_replace("[Specializzazione Istruttore]", $row['specializzazione'], $output);
    $output = str_replace("[Immagine Profilo]", $imageFile, $output);
    $output = str_replace("[ID Istruttore]", $row['id_utente'], $output);
    
    echo $output;
}

echo $bottom;
