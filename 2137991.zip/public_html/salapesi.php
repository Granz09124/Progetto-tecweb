<?php
session_start();
require __DIR__ . '/../internal/header.php';

renderPage(__DIR__ . "/../internal/palestra/salapesi/salapesi.html");

?>